# bryanjimenezchacon.github.io

Proyecto 1, Bases de Datos I, II Semestre 2015

Prototipo online de la página MatchMe: Cosis para cada corazon

Por:

Bryan Jimenez Chacon / 
Moises Alvarez Portuguez / 
Kenneth Callow Monge
