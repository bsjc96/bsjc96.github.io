grant create session to ge;
grant create table to ge;
grant create session to ge;

grant select on V_$SESSION  to ge;
grant select on V_$sesstat  to ge;
grant select on V_$STATNAME  to ge;

grant create view to ge;
grant create trigger to ge;
grant create any  directory to ge;
grant read on directory Imag_Perfil to ge;