DELETE FROM CIUDAD
where pais_id = '1' and ciudad = '1';


