DELETE FROM COLOR_OJOS
where color_OJOS_id = '1';
