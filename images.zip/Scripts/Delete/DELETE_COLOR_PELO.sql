DELETE FROM COLOR_PELO
where color_PELO_id ='1';
