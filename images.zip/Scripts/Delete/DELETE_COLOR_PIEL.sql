DELETE FROM COLOR_PIEL
where color_PIEL_id = '1';


