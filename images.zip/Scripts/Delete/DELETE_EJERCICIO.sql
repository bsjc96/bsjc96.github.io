DELETE FROM EJERCICIO
where ejercicio_id = '1';
