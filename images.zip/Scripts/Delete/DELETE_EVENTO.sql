DELETE FROM EVENTO
SET NOMBRE = 'ExpoEmpleo', FECHA = '12/03/2016', LUGAR = 'Antigua Aduana', DESCRIPCION = 'Feria de empleo'
where EVENTO_ID = '1'
;
