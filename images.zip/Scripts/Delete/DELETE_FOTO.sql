DELETE FROM FOTO
where FOTO_ID = '1'
;
