DELETE FROM FREQ_EJERCICIO
where ejercicio_id = '1';
