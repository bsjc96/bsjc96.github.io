DELETE FROM INTERES
where interes_id = '1';
