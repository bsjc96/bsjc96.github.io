DELETE FROM pais
where pais_id = '1';

