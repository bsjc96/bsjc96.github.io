DELETE FROM salario
where salario_id = '1';

