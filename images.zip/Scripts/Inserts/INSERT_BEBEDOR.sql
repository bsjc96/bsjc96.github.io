insert into BEBEDOR
(BEBEDOR_ID, TIPO)
values
('1', '1 bebida diaria' )
;
