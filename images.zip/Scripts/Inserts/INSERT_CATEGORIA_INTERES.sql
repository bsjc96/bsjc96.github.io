insert into CATEGORIA_INTERES
(CATEGORIA_INTERES_ID, NOMBRE)
values
('1', 'Bellas Artes' )
;

