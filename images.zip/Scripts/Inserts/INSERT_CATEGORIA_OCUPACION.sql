insert into CATEGORIA_OCUPACION
(CATEGORIA_OCUPACION_ID, NOMBRE)
values
('1', 'Salud' )
;
