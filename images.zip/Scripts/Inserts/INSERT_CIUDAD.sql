insert into CIUDAD
(CIUDAD, NOMBRE, PAIS_ID)
values
(1, 'San Jos�', 1)
;
