insert into COLOR_OJOS
(COLOR_OJOS_ID, NOMBRE)
values
('1', 'Verdes')
;

