insert into COLOR_PELO
(COLOR_PELO_ID, NOMBRE)
values
('1', 'Caf�')
;
