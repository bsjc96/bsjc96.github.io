insert into COLOR_PIEL
(COLOR_PIEL_ID, NOMBRE)
values
('1', 'Moreno')
;

