insert into CONTEXTURA
(CONTEXTURA_ID, TIPO)
values
('1', 'Gruesa')
;
