insert into EJERCICIO
(EJERCICIO_ID, NOMBRE)
values
('1', 'Abdominales' )
;
