insert into ESTADO_CIVIL
(ESTADO_CIVIL_id, NOMBRE)
values
(1, 'Union libre' )
;
