insert into EVENTO
(EVENTO_ID, NOMBRE, FECHA, LUGAR, DESCRIPCION)
values
('1', 'Embrujarte', '24/6/2016', 'Antigua Aduana', 'Feria de arte')
;
