insert into FOTO
(FOTO_ID, RUTA, USERNAME, NOMBRE)
values
('1', '1001101010101', 'Bryan365','Perfil.jpg')
;
