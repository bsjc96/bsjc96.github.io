insert into FREQ_EJERCICIO
(FREQ_EJERCICIO_id, RANGO)
values
(1, '1 vez por semana' )
;
