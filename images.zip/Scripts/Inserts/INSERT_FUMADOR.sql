insert into FUMADOR
(FUMADOR_ID, TIPO)
values
('1', 'Fumador social' )
;
