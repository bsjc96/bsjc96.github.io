insert into GENERO
(GENERO_id, NOMBRE)
values
(1, 'Masculino' )
;
