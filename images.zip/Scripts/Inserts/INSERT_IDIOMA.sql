insert into IDIOMA
(IDIOMA_ID, NOMBRE)
values
('1', 'Alem�n')
;
