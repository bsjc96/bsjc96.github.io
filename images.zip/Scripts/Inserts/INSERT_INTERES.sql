insert into INTERES
(INTERES_ID, NOMBRE)
values
('1', 'VISITAR MUSEOS' )
;
