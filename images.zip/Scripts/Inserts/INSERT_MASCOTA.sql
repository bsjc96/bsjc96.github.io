insert into MASCOTA
(MASCOTA_ID, TIPO)
values
('1', 'Perro' )
;
