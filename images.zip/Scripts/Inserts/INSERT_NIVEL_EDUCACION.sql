insert into NIVEL_EDUCACION
(NIVEL_EDUCACION_ID, GRADO)
values
('1', 'Escuela Completa')
;
commit;
