insert into OCUPACION
(OCUPACION_id, NOMBRE)
values
(1, 'Poeta' )
;
