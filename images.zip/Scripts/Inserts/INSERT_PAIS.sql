insert into PAIS
(PAIS_id, NOMBRE)
values
(1, 'Costa Rica' )
;
