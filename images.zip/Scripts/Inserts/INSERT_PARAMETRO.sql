insert into PARAMETROS
(PARAMETROS_ID, VALOR)
values
('Top_Winks', 20)
;
