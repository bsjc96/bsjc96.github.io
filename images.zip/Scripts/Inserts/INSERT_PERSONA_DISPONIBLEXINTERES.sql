insert into PERSONA_DISPONIBLEXINTERES
(USERNAME, INTERES_ID)
values
('Ale27', '1' )
;

