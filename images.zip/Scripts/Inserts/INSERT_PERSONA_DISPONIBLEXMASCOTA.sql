insert into PERSONA_DISPONIBLEXMASCOTA
(USERNAME, MASCOTA_ID)
values
('Ale27', '1' )
;

