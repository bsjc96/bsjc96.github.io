insert into RELIGION
(RELIGION_id, NOMBRE)
values
(1, 'Panteismo' )
;
