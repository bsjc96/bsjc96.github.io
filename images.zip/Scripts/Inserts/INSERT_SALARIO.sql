insert into SALARIO
(SALARIO_ID, RANGO)
values
(1, '0 - 150 000' )
;
