insert into PERSONA
(USERNAME, ES_ADMIN, NACIMIENTO, PRIMER_APELLIDO, SEGUNDO_APELLIDO, NOMBRE, GENERO_ID, CIUDAD_ID)
values
('Ale27', '0', '25/03/1987', 'Pereira', 'Molina', 'Alejandro',1,1 )
;
