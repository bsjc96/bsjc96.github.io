insert into Visita
(fecha_visita, visitante,visitado)
('25/08/2015', 'Bryan365', 'Moises99');
