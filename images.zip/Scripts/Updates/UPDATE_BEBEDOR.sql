UPDATE BEBEDOR
set TIPO ='1 vez a la semana'
where BEBEDOR_id = '1';
