update CIUDAD
set nombre = 'S�ndey'
where pais_id = '1' and ciudad = '1';


