UPDATE COLOR_OJOS
set nombre = 'Azul'
where color_OJOS_id = '1';
