UPDATE COLOR_PELO
set nombre ='Rubio'
where color_PELO_id ='1';
