UPDATE COLOR_PIEL
set nombre = 'Blanco'
where color_PIEL_id = '1';


