update EJERCICIO
set nombre = 'Yoga'
where ejercicio_id = '1';
