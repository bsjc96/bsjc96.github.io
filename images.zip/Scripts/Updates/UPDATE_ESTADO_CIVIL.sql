UPDATE ESTADO_CIVIL
set NOMBRE ='Soltero/a'
where ESTADO_CIVIL_id = '1';
