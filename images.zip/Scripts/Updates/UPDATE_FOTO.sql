UPDATE FOTO
SET RUTA = '123321123', NOMBRE = 'Paseo.jpg'
where FOTO_ID = '1'
;
