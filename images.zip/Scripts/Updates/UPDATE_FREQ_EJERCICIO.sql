update FREQ_EJERCICIO
set rango = '3-4 veces a la semana'
where ejercicio_id = '1';
