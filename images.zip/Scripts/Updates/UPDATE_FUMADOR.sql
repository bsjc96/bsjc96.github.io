UPDATE FUMADOR
set TIPO ='Habitual'
where FUMADOR_id = '1';
