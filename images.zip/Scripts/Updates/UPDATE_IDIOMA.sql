UPDATE IDIOMA
set nombre= 'Esperanto'
where IDIOMA_id = '1';
