update INTERES
set NOMBRE = 'Manualidades'
where interes_id = '1';
