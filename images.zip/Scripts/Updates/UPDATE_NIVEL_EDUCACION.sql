UPDATE INTERES
set NOMBRE ='Universidad Completa'
where INTERES_id = '1';
