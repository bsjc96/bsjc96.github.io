UPDATE OCUPACION
set NOMBRE ='Bailarin/a'
where OCUPACION_id = '1';
