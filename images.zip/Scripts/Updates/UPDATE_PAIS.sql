update pais
set nombre = 'Australia'
where pais_id = '1';

