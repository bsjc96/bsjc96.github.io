UPDATE RELIGION
set NOMBRE ='Pastafariano'
where RELIGION_id = '1';
