update salario
set rango = '100 000 - 150 000'
where salario_id = '1';

